import Functional_NN_1D as nets
import numpy as np
import random
import copy
import polynomial_Functions_1D as poly
import math
import os

print("we are a go and we go")

def get_matrix_numbs_form_file(loc,name):
	with open(loc+name+".txt","r") as f:
		array=[""]
		for line in f:
			m=line
			m=m.strip("\n")
			m=m.split(",")
			for x in range(len(m)):
				m[x]=float(m[x])
			array.append(m)
	f.close()
	array.pop(0)
	return array

	return net


def make_begining_row_for_NN(data,number,row):#makes the first row of NN
	theout=[0]*number
	#print("number ",len(data))
	newonw=np.arange(len(data))
	for x in range(len(data)):
		newonw[x]=data[x]
	out1=poly.return_Function_C_S(newonw,0,1,row)
	for y in range(number):
		theout[y]=poly.shift_function(out1,len(data),row, y/math.pi)
	return theout

def vecmult(vec,number): # multipys vector by consent
	out=[0]*len(vec)
	for x in range(len(vec)):

		out[x]=[vec[x][0]*number]
	return out




row=[19,15,19]
#row is the number of aproximations in a row
net_type=[50,10,1]
#net specifys the type of network how many nods in each row




cdw=os.getcwd()
loc=cdw+"/try1p/"
location_of_ones_and_zeros=cdw


newnet=nets.get_net(loc,net_type)
# the new netthat will be used for 

#uncoment to make a randome net
newget = input("make new net")
if newget=="y":
	newnet=nets.make_random_net_with_bies(net_type,row)
#'/Users/ahauss/Desktop/popredone/try1p/L0/con0.txt
#/Users/ahauss/Desktop/popredone/2p/try1p/L0


zero_objective=[0.5,0,0.1]
#the objective of the zero image
one_objective=[0.5,0,-0.1]
#the objective of the one image





#number of ones and zeros
num_ones_and_zeros = 900
oneimg=[0]*num_ones_and_zeros
zerimg=[0]*num_ones_and_zeros

output_objective_tensor=[0]*1800
#output objective

start_data_tensor=[0]*1800
#start data tensor
for x in range(num_ones_and_zeros):
	oneimg[x]=get_matrix_numbs_form_file(location_of_ones_and_zeros,"/1/0_"+str(x+1)+"")
	zerimg[x]=get_matrix_numbs_form_file(location_of_ones_and_zeros,"/0/0_"+str(x+1)+"")
	output_objective_tensor[2*x+0]=[one_objective]
	start_data_tensor[2*x+0]=[oneimg[x][0]]

	output_objective_tensor[2*x+1]=[zero_objective]
	start_data_tensor[2*x+1]=[zerimg[x][0]]
#gets imiage data


lear_rate=[[1.4],[1.4],[1.4],[0.014],[1]]
#the learing rate for the network

numberofloops=2
#the number of loops each time a new atemt is made


mfd = {}






onefuc=[0.5,0,0.1]

this_start=make_begining_row_for_NN(start_data_tensor[0][0],net_type[0],row[0])
#this run thoughts start datfa

out=nets.for_ward_prop2(newnet,this_start,net_type,mfd,row)

number_of_imiages_used=1
offset=0
print()
print("number of decents",number_of_imiages_used)
for x in range(1):
	total=0
	theoldnet=copy.deepcopy(newnet)
	for y in range(number_of_imiages_used):
		print("y",y," x",x)

		this_start=make_begining_row_for_NN(start_data_tensor[y+offset][0],net_type[0],row[0])
		#this run thoughts start data 

		for z in range(5):
			print("z ",z)
			try:
				output_for_this_net=nets.for_ward_prop2(newnet,this_start,net_type,mfd,row)
				mult=poly.differance(output_for_this_net[len(output_for_this_net)-1][0],output_objective_tensor[y+offset][0],100,mfd)
				print("",mult)
				newnet=nets.back_ward_prop(newnet,output_objective_tensor[y+offset],net_type,output_for_this_net,vecmult(lear_rate,0.01),mfd,row)
			except:
				pass
				print("fail")
			else:
				pass
			finally:
				pass

		output_for_this_net=nets.for_ward_prop2(newnet,this_start,net_type,mfd,row)
		here=poly.differance(output_for_this_net[len(output_for_this_net)-1][0],onefuc,100,mfd)
		print("total_diferance_on_this_image",here)
	
	print("the test")
	numberoftests=0
	sumoftests=0
	sumoftestpoints=0
	offset_test=0
	try:
		for x in range(2):

			print("x",x)
			theway=make_begining_row_for_NN(start_data_tensor[x+offset_test][0],net_type[0],row[0])
			output_for_this_net=nets.for_ward_prop2(newnet,theway,net_type,mfd,row)
			onefuc=[0.5,0,0.1]
			zerofuc=[0.5,0,-0.1]
			one=poly.differance(output_for_this_net[len(out)-1][0],onefuc,100,mfd)
			zero=poly.differance(output_for_this_net[len(out)-1][0],zerofuc,100,mfd)

			print("1 ",one," 0",zero)
			if x%2:
				if one>zero:
					print("fase")
					
				else:
					print("true")
					sumoftestpoints+=1
			else:
				if one<zero:
					print("flase")
					
				else:
					print("true")
					sumoftestpoints+=1
	except:
		pass



offset_test=0
for x in range(100):
	theway=make_begining_row_for_NN(start_data_tensor[x+offset_test][0],net_type[0],row[0])
	out=nets.for_ward_prop2(newnet,theway,net_type,mfd,row)
	print(out[len(out)-1][0])
	poly.plotfunction(out[len(out)-1][0],1000)


print("we go")
for x in range(0):
	poly.plotfunction(start[x][0],1000)

print("the imp len")
input()
nets.store_net(loc,newnet)
print("we saved the net")
#5.002742135796178
